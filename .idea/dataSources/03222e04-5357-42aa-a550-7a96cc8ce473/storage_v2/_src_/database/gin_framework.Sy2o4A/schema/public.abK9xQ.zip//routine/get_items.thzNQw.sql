create function get_items()
    returns TABLE(item_id numeric, item_name character varying, item_price numeric)
    language plpgsql
as
$$
BEGIN
        return query
        SELECT item_id, item_name, item_price FROM view_item LIMIT 20;
    end;
$$;

alter function get_items() owner to testadmin;

